package main;

import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class Person implements Serializable{

	private String fullName;
	private String firstName;
	private String lastName;
	private String ssn;
	private String email;
	private String phoneNumber;
	
	
	final String regexFullName = "(\\w*) (\\w*)";
	final String regexSSN = "\\d{3}-\\d{2}-\\d{4}";
	final String regexEmail = "\\w*@\\w*\\.[^,]+";
	final String regexPhone = "\\d{3}-\\d{3}-\\d{4}$";
	



	
	public Person(String line) {
		Pattern p = null;
		Matcher m = null;
		
		p = Pattern.compile(regexFullName);
		m = p.matcher(line);
		if(m.find()) {
			this.fullName = m.group();
			this.firstName = m.group(1);
			this.lastName = m.group(2);
		}
		
		
		p = Pattern.compile(regexSSN);
		m = p.matcher(line);
		if(m.find()) {
			this.ssn = m.group();
		}
		
		p = Pattern.compile(regexEmail);
		m = p.matcher(line);
		if(m.find()) {
			this.email = m.group();
		}
		
		p = Pattern.compile(regexPhone);
		m = p.matcher(line);
		if(m.find()) {
			this.phoneNumber = m.group();
		}else {
			throw new IllegalArgumentException("This person's phone number is wrong");
		}
	}
	
	
	@Override
	public String toString() {
		return  "Full Name: " + fullName +
				"\nFirst Name: " + firstName +
				"\nLast Name: " + lastName +
				"\nSSN: " + ssn +
				"\nEmail: " + email +
				"\nPhone Number: " + phoneNumber + "\n-------------------";
	}
}


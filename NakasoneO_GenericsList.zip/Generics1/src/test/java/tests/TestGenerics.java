package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import generics1.MyArrayList;

public class TestGenerics {

	
	
	@Test
	public void testAdd() {
		MyArrayList<Double> stringList = new MyArrayList<Double>();
		stringList.add(20.2);
		stringList.add(34.1);
		stringList.add(56.89);
		
		System.out.println(stringList.toString() + "\n");
		assertEquals(stringList.size(), 3);
	}
	
	@Test
	public void testRemove() {
		MyArrayList<String> stringList = new MyArrayList<String>();
		stringList.add("test 1");
		stringList.add("test 2");
		stringList.add("test 3");
		stringList.remove("test 1");
		
		System.out.println(stringList.toString() + "\n");
		assertEquals(stringList.size(), 2);
		
	}
	@Test
	public void testGetArrayList() {
		MyArrayList<Integer> stringList = new MyArrayList<Integer>();
		stringList.add(1);
		stringList.add(2);
		stringList.add(3);
		
		System.out.println(stringList.get()+ "\n");
	}
	
	@Test
	public void testSize() {
		MyArrayList<Boolean> stringList = new MyArrayList<Boolean>();
		stringList.add(true);
		stringList.add(false);
		stringList.add(null);
		
		
		System.out.println(stringList.toString() + "\n");
		assertEquals(stringList.size(), 3);
	}

}

package data_validation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TesterDataValidation {
	
	String html = "<p>Contents in p tag <code>Contents in code tag1</code> Contents in p tag2</p><code>Contents in code tag2</code>";
	
	@Test
	void testValidName() {
		String testName = "Mr. Odin S Nakasone";
		boolean name = Controller.isValidHumanName(testName);
		System.out.println("\nValid Name Status: " + name);
	
		System.out.println(testName + "\n");
	}
	
	
	@Test
	void testInvalidName() {
		String testName = "mr. Odin S Nakasone";
		boolean name = Controller.isValidHumanName(testName);
		
		if(name == false) {
			throw new IllegalArgumentException("The name was invalid");
		}
	}
	
	@Test
	void testValidEmail() {
		String testEmail = "test@gmail.com";
		boolean email = Controller.isValidEmailAddress(testEmail);
		System.out.println("\nValid Email Status: " + email);
		
	    System.out.println(testEmail + "\n");
		
	}
	
	@Test
	void testInvalidEmail() {
		String testEmail = "testgmail.com";
		boolean email = Controller.isValidEmailAddress(testEmail);
		
		if(email == false) {
			throw new IllegalArgumentException("The email was invalid");
		}
	}
	
	@Test
	void testValidPhoneNumber() {
		String testPhone = "828-123-3456";
		boolean phone = Controller.isValidPhoneNumber(testPhone);
		System.out.println("Valid Phone Number Status: " + phone);
		
		System.out.println(testPhone + "\n");
		
	}
	
	@Test
	void testInvalidPhoneNumber() {
		String testPhone = "828-123-34526";
		boolean phone = Controller.isValidPhoneNumber(testPhone);
		
		if(phone == false) {
			throw new IllegalArgumentException("The phone number was invalid");
		}
	}
	
	@Test
	void testValidSSN() {
		String testSSN = "122-34-7892";
		boolean ssn = Controller.isValidSSN(testSSN);
		System.out.println("Valid SSN Status: " + ssn);
		
		System.out.println(testSSN + "\n");
		
	}
	
	@Test
	void testInvalidSSN() {
		String testSSN = "1222-34-7892";
		boolean ssn = Controller.isValidSSN(testSSN);
		
		if(ssn == false) {
			throw new IllegalArgumentException("The SSN was invalid");
		}
	}
	
	@Test 
	void testValidUSStreetAddress() {
		String testUSAddress = "123 West Main St. Salt Lake City, UT 84102";
		boolean USAddress = Controller.isValidUSStreetAddress(testUSAddress);
		System.out.println("\nValid US Address Status: " + USAddress);
		
		System.out.println(testUSAddress + "\n");
		
	}
	
	@Test 
	void testInvalidUSStreetAddress() {
		String testUSAddress = "123 West";
		boolean USAddress = Controller.isValidUSStreetAddress(testUSAddress);
		
		if(USAddress == false) {
			throw new IllegalArgumentException("The US Address was invalid");
		}
	}
	
	@Test
	void testValidPassword() {
		String testPassword = "Nakasone11!";
		int minLength = 4;
		int minUpper = 1;
		int minLower = 1;
		int minNumeric = 1;
		int minSymbols = 1;
		boolean validPassword = Controller.validatePasswordComplexity(testPassword, minLength, minUpper, minLower, minNumeric, minSymbols);
		System.out.println("Valid Password Status: " + validPassword);
		
		
		System.out.println(testPassword);
	
				
	}
	
	@Test
	void testInvalidPassword() {
		String testPassword = "IREALLYLIKECODING 1";
		int minLength = 4;
		int minUpper = 1;
		int minLower = 1;
		int minNumeric = 1;
		int minSymbols = 1;
		boolean validPassword = Controller.validatePasswordComplexity(testPassword, minLength, minUpper, minLower, minNumeric, minSymbols);
		
		if(validPassword == false) {
			throw new IllegalArgumentException("The password doesn't match the requirements");
		}
				
	}
	
	@Test
	void testValidCountContains() {
		String needle = "[l]";
		String haystack = "Hello";
		
		int count = Controller.countContains(needle, haystack);
		
		System.out.println("Needle: " + needle);
		System.out.println("The haystack: " + haystack);
		System.out.println("Number of needles: " + count);
	
	}
	
	@Test
	void testInvalidCountContains() {
		String needle = "[l]";
		String haystack = "Odin";
		
		int count = Controller.countContains(needle, haystack);
		
		if(count == 0) {
			throw new IllegalArgumentException("There are no needles in the haystack");
		}
	}
	
	@Test
	void testValidGetHTMLTagContents() {
		String tag = "p";
		String s = Controller.getHTMLTagContents(html, tag);
		System.out.println("Content in " + tag + " tag: \n" + s);
		
	}
	
	@Test
	void testInvalidGetHTMLTagContents() {
		String tag = "s";
		String s = Controller.getHTMLTagContents(html, tag);
		
		if(s.isBlank()) {
			throw new IllegalArgumentException("There was no matches in the " + tag + " tag.");
		}
	}
	
	@Test
	void testValidGetHTMLTagsContents() {
		String[] tags = Controller.getHTMLTagsContents(html, "code");
		System.out.println("Contents in <code> tag:");
		
		for(String tag : tags) {
			System.out.println(tag);
		}
	}
	
	@Test
	void testInvalidGetHTMLTagsContents() {
		String inputTag = "codes";
		String[] tags = Controller.getHTMLTagsContents(html, inputTag);
		
		if(tags.length == 0) {
			throw new IllegalArgumentException("There was no matches in the " + inputTag + " tag.");
		}
		
		for(String tag : tags) {
			System.out.println(tag);
		}
		
	}
	
	@Test
	void testValidGetHTMLLinkURL() {
		String html1 = "<a href=\"google.com\"";
		String html2 = "<a href=\"netflix.com\"";
		String html = "<a href=\"youtube.com\""+ html1 + html2;
		String[] destinations = Controller.getHTMLLinkURL(html);
		
		System.out.println("\nContents in <a href> tag:");
		
		for(String destination: destinations) {
			System.out.println(destination);
		}
	}
	
	@Test
	void testInvalidGetHTMLLinkURL() {
		String html1 = "<b href=\"google.com\"";
		String html2 = "<b href=\"netflix.com\"";
		String html = "<b href=\"youtube.com\""+ html1 + html2;
		String[] destinations = Controller.getHTMLLinkURL(html);
		
		System.out.println("\nContents in <a href> tag:");
		
		if(destinations.length == 0) {
			throw new IllegalArgumentException("There was no matches in the <a href> tag.");
		}
		
		for(String destination: destinations) {
			System.out.println(destination);
		}
	}

}

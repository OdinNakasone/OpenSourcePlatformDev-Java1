package data_validation;

public class Main {

	public static void main(String[] args) {
		Controller.run();

	}

}

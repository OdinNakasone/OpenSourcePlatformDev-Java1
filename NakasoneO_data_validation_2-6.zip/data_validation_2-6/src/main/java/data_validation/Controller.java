package data_validation;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Controller {

	private static Pattern p;
	private static Matcher m;

	public static void run() {

	}

	public static boolean isValidHumanName(String name) {
		boolean isInvalid = false;
		String regexFullName = "^[A-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$";

		try {
			p = Pattern.compile(regexFullName);
			m = p.matcher(name);
			
			if (m.find()) {
				isInvalid = true;
			}	
		}catch(IllegalArgumentException i) {
			i.printStackTrace();
		}

		return isInvalid;

	}

	public static boolean isValidEmailAddress(String email) {
		boolean isInvalid = false;
		String regexEmail = "^\\w+@[a-zA-Z_]+?\\.[a-zA-Z]{2,3}$";

		try {
			p = Pattern.compile(regexEmail);
			m = p.matcher(email);
			
			if (m.find()) {
				isInvalid = true;
			}			
		}catch(IllegalArgumentException i) {
			i.printStackTrace();
		}

		return isInvalid;
	}

	public static boolean isValidPhoneNumber(String phone) {
		boolean isInvalid = false;
		String regexPhone = "^[2-9]\\d{2}-\\d{3}-\\d{4}$";
		
		try {
			p = Pattern.compile(regexPhone);
			m = p.matcher(phone);
			
			if(m.find()) {
				isInvalid = true;
			}
		}catch(IllegalArgumentException i) {
			i.printStackTrace();
		}
		
		
		
		
		return isInvalid;
	}

	public static boolean isValidSSN(String ssn) {
		boolean isInvalid = false;
		String regexSSN = "^\\d{3}-\\d{2}-\\d{4}$";
		
		try {
			p = Pattern.compile(regexSSN);
			m = p.matcher(ssn);

			if (m.find()) {
				isInvalid = true;
			}
		}catch(IllegalArgumentException i) {
			i.printStackTrace();
		}
		
		return isInvalid;
	}

	public static boolean isValidUSStreetAddress(String street) {
		boolean isInvalid = false;
		String regexUSStreetAddress = "^[ \\w]{3,}([A-Za-z]\\.)?([ \\w]*\\#\\d+)?(\\r\\n| )[ \\w]{3,},\\x20[A-Za-z]{2}\\x20\\d{5}(-\\d{4})?$";

		try {
			p = Pattern.compile(regexUSStreetAddress);
			m = p.matcher(street);
			
			if (m.find()) {
				isInvalid = true;
			}
		}catch(IllegalArgumentException i) {
			i.printStackTrace();
		}

		return isInvalid;
	}

	public static boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower,
			int minNumeric, int minSymbols) {
		
		boolean isInvalid = false;
		String regexPassword = 
				"^(?=.*\\d{" + minNumeric + "})"
				+ "(?=.*[a-z]{" + minLower + "})"
				+ "(?=.*[A-Z]{" + minUpper + "})"
				+ "(?!.*\\s{" + minSymbols + "})."
				+ "{" + minLength + ",30}$";
		try {
			
			p = Pattern.compile(regexPassword);
			m = p.matcher(password);
			
			if (m.find()) {
				isInvalid = true;
			}
			
		}catch(IllegalArgumentException i) {
			i.printStackTrace();
		}
		return isInvalid;
	}

	public static int countContains(String needle, String haystack) {
		int needleCount = 0;
		
		try {
			p = Pattern.compile(needle);
			m = p.matcher(haystack);
			
			while(m.find()) {
				needleCount++;
			}
			
		}catch(IllegalArgumentException i) {
			i.printStackTrace();
		}
		return needleCount;
	}

	public static String getHTMLTagContents(String html, String tagName) {
		String regex = "<" + tagName + ">(.+?)</" + tagName + ">";
		String tagGroup = null;
//		System.out.println("Regex: " + regex);

		try {
			p = Pattern.compile(regex);
			m = p.matcher(html);

			if (m.find()) {
				tagGroup = m.group(1);
			}
		}catch(IllegalArgumentException i) {
			i.printStackTrace();
		}
		

		return tagGroup;
	}

	public static String[] getHTMLTagsContents(String html, String tagName) {
		ArrayList<String> tags = new ArrayList<String>();
		String regex = "<" + tagName + ">(.+?)</" + tagName + ">";
		String tagGroup = null;
//		System.out.println("Regex: " + regex);

		try {
			p = Pattern.compile(regex);
			m = p.matcher(html);

			

			while (m.find()) {
				tagGroup = m.group(1);
				tags.add(tagGroup);
			}
		}catch(IllegalArgumentException i) {
			i.printStackTrace();
		}
		

		return tags.toArray(new String[0]);
	}

	public static String[] getHTMLLinkURL(String html) {
		ArrayList<String> destinations = new ArrayList<String>();
		String regex = "<a[^>]* href=\"([^\"]*)\"";
;
		try {
			p = Pattern.compile(regex);
			m = p.matcher(html);

		
			while (m.find()) {
				html = m.group();
				destinations.add(html);
			}
		}catch(IllegalArgumentException i) {
			i.printStackTrace();
		}
		

		return destinations.toArray(new String[0]);
	}

}

package stocktrades;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class tester {
	
	static Stock_Trading_main stockTrades = new Stock_Trading_main();

	@Test
	static void testCreatePDF() {
		
	}

	@Test
	static void testReadJSON() {
//		int estimatedJsonSize = 300;
//		int jsonSize = Stock_Trading_main.readJSON();
//		
//		assertEquals(estimatedJsonSize, jsonSize);
		
	}
	
	@Test
	static void writeHTML() {
		
	}
}

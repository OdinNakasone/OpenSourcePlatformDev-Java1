package stocktrades;

import java.io.*;
import java.util.*;
import java.time.LocalDate;

import org.json.simple.JSONArray;	
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;

public class Stock_Trading_main {
	
	static String folder = "misc\\";

	public static void main(String[] args) {

		 readJSON();
		//writeHTML();

	}
	
	public static boolean createPDF(String filename) {
		try {
			OutputStream os = new FileOutputStream(folder + filename + ".pdf");
			PdfRendererBuilder builder = new PdfRendererBuilder();
			File f = new File(folder + filename + ".html");
			builder.useFastMode();
			// builder.withUri("file:///Users/me/Documents/pdf/in.htm");
			builder.withFile(f);
			builder.toStream(os);
			builder.run();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return true;
	}


	public static boolean writeHTML(JSONObject customerRecord) {
		LocalDate date = LocalDate.now();
		String htmlTop = "<!DOCTYPE html><html><body>\r\n";
		String htmlBottom = "</body></html>";
		String htmlCustomerInfo = String.format("<h1>%s</h1><p>%s %s</p>\r\n<p>%s</p>\r\n", date.toString(),
				(String) customerRecord.get("first_name"), (String) customerRecord.get("last_name"), (String) customerRecord.get("ssn"));
		
		String htmlTableTradeTop = "<table style=\"width:100%\">\r\n<tr><th>Type</th><th>Symbol</th><th>Price</th><th># Shares</th><th>Total</th></tr>\r\n";
		
		JSONArray trades = (JSONArray) customerRecord.get("stock_trades");
		ArrayList<String> htmlTableTradeDetails = new ArrayList<String>();	
		Double total = 0.0;
		Double buy = 0.0;
		Double sell = 0.0;
		
		
		for (int ii = 0; ii < trades.size(); ii++) {
			JSONObject trade = (JSONObject) trades.get(ii);
			// String trade_type = (String) trade.get("type");
			 total = Double.parseDouble(trade.get("price_per_share").toString().substring(1)) *  Double.parseDouble(trade.get("count_shares").toString().substring(1));
			 
			
			htmlTableTradeDetails
					.add(String.format("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\r\n",
							trade.get("type").toString(), trade.get("stock_symbol").toString(),
							trade.get("price_per_share").toString(), trade.get("count_shares").toString(), String.valueOf(total)));
			
			
			
			
//			System.out.println(total);
			
			if(trade.get("type").toString().contains("Buy")) {
				buy = Double.parseDouble(customerRecord.get("beginning_balance").toString().substring(1)) - total;
			}
			else if(trade.get("type").toString().contains("Sell")) {
				sell = Double.parseDouble(customerRecord.get("beginning_balance").toString().substring(1)) + total;
			}
		}

		
		
		String htmlTableTradeBottom = "</table>\r\n";
		
		String htmlSummary = String.format("<p>Cash Value: %s</p>\r\n<p>Stock Value: %s</p>\r\n", String.valueOf(sell), String.valueOf(buy));
		
		String filename = customerRecord.get("account_number").toString();
		
		



		FileWriter fw = null;

		try {
			fw = new FileWriter("misc\\" + filename + ".html");
			fw.write(htmlTop);
			fw.write(htmlCustomerInfo);
			fw.write(htmlTableTradeTop);
			
			for (String s : htmlTableTradeDetails) {
				fw.write(s);
			}

			fw.write(htmlTableTradeBottom);
			fw.write(htmlSummary);
			fw.write(htmlBottom);

		} catch (IOException ioe1) {
			ioe1.printStackTrace();

		} finally {
			try {
				if (fw != null)
					fw.close();
			} catch (IOException ioe2) {
				ioe2.printStackTrace();
			}
		}
		
		createPDF(filename);
		
		return true;

	}

	public static int readJSON() {
		int arraySize = 0;
		try {
			Object json = new JSONParser()
					.parse(new FileReader("misc\\stock_transations.by.account.holder.json"));
			JSONArray jsonA = (JSONArray) json;
			arraySize = jsonA.size();
			
			

			for (int i = 0; i < jsonA.size(); i++) {
				JSONObject customer_record = (JSONObject) jsonA.get(i);
				writeHTML(customer_record);
			}
			
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return arraySize;
		
		
		
		
	}

}

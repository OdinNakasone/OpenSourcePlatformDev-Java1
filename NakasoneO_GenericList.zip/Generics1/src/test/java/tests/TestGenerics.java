package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import generics1.MyArrayList;

public class TestGenerics {

	
	
	@Test
	public void testAdd() {
		MyArrayList<String> stringList = new MyArrayList<String>();
		stringList.add("test 1");
		stringList.add("test 2");
		stringList.add("test 3");
		
		System.out.println(stringList.toString() + "\n");
		assertEquals(stringList.size(), 3);
	}
	
	@Test
	public void testRemove() {
		MyArrayList<String> stringList = new MyArrayList<String>();
		stringList.add("test 1");
		stringList.add("test 2");
		stringList.add("test 3");
		stringList.remove("test 1");
		
		System.out.println(stringList.toString() + "\n");
		assertEquals(stringList.size(), 2);
		
	}
	@Test
	public void testGetArrayList() {
		MyArrayList<String> stringList = new MyArrayList<String>();
		stringList.add("test 1");
		stringList.add("test 2");
		stringList.add("test 3");
		
		System.out.println(stringList.get()+ "\n");
	}
	
	@Test
	public void testSize() {
		MyArrayList<String> stringList = new MyArrayList<String>();
		stringList.add("test 1");
		stringList.add("test 2");
		stringList.add("test 3");
		stringList.add("test 4");
		stringList.add("test 5");
		stringList.add("test 6");
		
		System.out.println(stringList.toString() + "\n");
		assertEquals(stringList.size(), 6);
	}

}

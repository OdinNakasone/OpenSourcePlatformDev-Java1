package generics1;

import java.util.ArrayList;

public class MyArrayList<T> implements MyList<T> {
	
	ArrayList<T> arrayList = new ArrayList<T>();

	public void add(T val) {
		arrayList.add(val);
		
	}

	public void remove(T val) {
		
		arrayList.remove(val);
		
	}

	public ArrayList<T> get() {
		return this.arrayList;
	}

	public int size() {
		return arrayList.size();
	}
	
	@Override
	public String toString() {
		return "ArrayList Contents: " + arrayList;
	}

	
	
}

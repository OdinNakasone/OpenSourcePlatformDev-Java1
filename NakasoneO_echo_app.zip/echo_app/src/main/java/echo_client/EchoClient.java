package echo_client;
import java.net.*;
import java.io.*;

public class EchoClient {

	public static void main(String[] args) throws IOException{
		String hostName = "127.0.0.1";
		System.out.println("Attempting to connect to " + hostName);
		
		Socket echoSocket = null;
		PrintWriter out = null;
		BufferedReader in = null;
		
		try {
			echoSocket = new Socket(hostName, 10007);
			out = new PrintWriter(echoSocket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(echoSocket.getInputStream()));
			
		}catch(Exception e) {
			System.err.println("Don't know about host: " + hostName);
			System.exit(1);
		}
		
		BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
		String userInput;
		
		System.out.println("Your input: ");
		
		while((userInput = stdIn.readLine()) != null) {
			out.println(userInput);
			System.out.println(in.readLine());
			System.out.println("input: ");
		}
		
		out.close();
		in.close();
		stdIn.close();
		echoSocket.close();
	}
}

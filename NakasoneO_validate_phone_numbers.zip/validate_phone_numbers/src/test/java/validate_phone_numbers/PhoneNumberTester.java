package validate_phone_numbers;

import static org.junit.Assert.*;

import org.junit.Test;

public class PhoneNumberTester {
	
	Person person = new Person();

	@Test
	public void testPhoneNumberFail() {
		String testPhoneNum = "800-123-abcd";
		
		person.setPhoneNumber(testPhoneNum);
		
	}
	
	@Test
	public void testPhoneNumberPass() {
		String testPhoneNum = "800-123-4567";
		
		person.setPhoneNumber(testPhoneNum);
		
	}

}

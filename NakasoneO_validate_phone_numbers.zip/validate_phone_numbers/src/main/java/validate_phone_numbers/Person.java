package validate_phone_numbers;



public class Person {
	
	private String phoneNumber;
	private ValidatePhoneNumbersMain validate;
	
	
	public String getPhoneNumber() {
		
		return phoneNumber;
	}
	
	public Person() {
		
	}
	
	public Person(String phoneNumber) {
		setPhoneNumber(phoneNumber);
	}
	
	public void setPhoneNumber(String phoneNumber) {
		
		ValidatePhoneNumbersMain.regExRunner(phoneNumber, "^[2-9]\\d{2}-\\d{3}-\\d{4}$" );
		
		this.phoneNumber = phoneNumber;
	}
	
	@Override
	public String toString() {
		return "Person's Phone Number: " + phoneNumber;
	}
	

}

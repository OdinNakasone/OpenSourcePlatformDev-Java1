package validate_phone_numbers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidatePhoneNumbersMain {
	
	static Person person = new Person();

	public static void main(String[] args) {
		run();
	}
	
	public static void run() {
		String phoneNumber = "808-133-4566";
		
		person.setPhoneNumber(phoneNumber);
	}
	
	public static void regExRunner(String str, String regex) {
		System.out.println("--> " + str + ", " + regex);

		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(str);

//		int groupCount = m.groupCount();
//		System.out.println("--> Group Count: " + groupCount);
		

		int matchCount = 0;
		if(m.find()) {
			matchCount++;
			System.out.println("Match # " + matchCount + " = " + m.group());
			System.out.println("Begin: " + m.start() + " , End: " + m.end());
		}else {
			throw new IllegalArgumentException("The phone number is wrong");
		}
		

		System.out.println("--> There are " + matchCount + " total matches\r\n");

//		if (replacement != null) {
//			// String newStr = m.replaceFirst("cats");
//			String newStr = m.replaceAll("cats");
//			System.out.println("--> Modified String: " + newStr + "\r\n");
//		}

	}

}

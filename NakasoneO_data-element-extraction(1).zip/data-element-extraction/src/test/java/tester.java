import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import main.Main;
import main.Person;

public class tester {
	
	ArrayList<Person> persons = new ArrayList<Person>();

	@Test
	public void test() {
		for(Person p : persons) {
			System.out.println(p);
		}
	}

}

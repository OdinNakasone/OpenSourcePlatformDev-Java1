package main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class Main {

	public static void main(String[] args) {
		run();

	}
	
	public static void run() {
		ArrayList<String> lines = readLines();
		ArrayList<Person> persons = createPerson(lines);
		
		for(Person p : persons) {
			System.out.println(p);
		}
	}
	
	public static ArrayList<Person> createPerson(ArrayList<String> lines) {
		
		
		ArrayList<Person> persons = new ArrayList<Person>();
		
		lines.remove(0);
		for(String line: lines) {
			try {
				Person p = new Person(line);
				
				persons.add(p);
			}catch (IllegalArgumentException i) {
				i.printStackTrace();
			}
			
		}
		
		return persons;
	}
	
	public static ArrayList<String> readLines() {
		String filename = "people.to.regex.csv";
		File f = new File(filename);
		ArrayList<String> lines = new ArrayList<String>();
		
		if(f.exists()) {
			System.out.println("File Found\n");
			
			BufferedReader reader;
			try {
				
				reader = new BufferedReader(new FileReader(f));
				
				String line = reader.readLine();
				while(line != null) {
					//System.out.println(line);
					lines.add(line);
					line = reader.readLine();
					
				}
				
				reader.close();
				
			}catch(IOException i) {
				i.printStackTrace();
			}
			
		}
		
		
		else {
			System.out.println("File not Found");
		}
		
		return lines;
	}
	
	

}

